from urllib import response
from django.shortcuts import render

from django.http import HttpResponse

def index(request):
    return HttpResponse("Desde la visa de operaciones!")

def sumar(request):
    return HttpResponse("Desde la vista de suma")
    
def resultadoSuma(request, numero1,numero2):
    responde = "El resultado de la suma es %s"
    return HttpResponse(responde % {numero1 + numero2})

def restar(request):
    return HttpResponse("Desde la vista de resta")

def resultadoResta(request, numero1,numero2):
    responde = "El resultado de la resta es %s"
    return HttpResponse(responde % {numero1 - numero2})

def multiplicar(request):
    return HttpResponse("Desde la vista de multiplicación")

def resultadoMultiplicar(request, numero1,numero2):
    responde = "El resultado de la multiplicacion es %s"
    return HttpResponse(responde % {numero1 * numero2})

def dividir(request):
    return HttpResponse("Desde la vista de división")

def resultadoDividir(request, numero1,numero2):
    responde = "El resultado de la division es %s"
    return HttpResponse(responde % {numero1/numero2})

