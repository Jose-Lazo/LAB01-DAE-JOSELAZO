from django.apps import AppConfig


class SumarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sumar'
