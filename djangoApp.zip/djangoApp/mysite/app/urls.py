from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('sumar/', views.sumar, name = 'sumar'),
    path('sumar/<int:numero1>/<int:numero2>/resultadoSuma', views.resultadoSuma, name = 'resultadoSuma'),
    path('restar/', views.restar, name = 'restar'),
    path('restar/<int:numero1>/<int:numero2>/resultadoResta', views.resultadoResta, name = 'resultadoResta'),
    path('multiplicar/', views.multiplicar, name = 'multiplicar'),
    path('multiplicar/<int:numero1>/<int:numero2>/resultadoMultiplicar', views.resultadoMultiplicar, name = 'resultadoMultiplicar'),
    path('dividir/', views.dividir, name = 'dividir'),
    path('dividir/<int:numero1>/<int:numero2>/resultadoDividir', views.resultadoDividir, name = 'resultadoDividir'),
]
